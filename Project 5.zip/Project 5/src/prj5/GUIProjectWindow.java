/**
 * 
 */
package prj5;

import java.awt.Color;
import java.util.Iterator;
import CS2114.Button;
import CS2114.Shape;
import CS2114.TextShape;
import CS2114.Window;
import CS2114.WindowSide;

/**
 * Has the display where the user will interact with the buttons to view the
 * information
 * 
 * @author Ben Bilbro (benb16), Sean Seth (ssean7), Tej Patel (tej0126)
 * @version April 19, 2017
 *
 */
public class GUIProjectWindow
{

    private LinkedList<GUIGlyph> gList;
    private Window window;
    private Button prev;
    private Button sortArtist;
    private Button sortTitle;
    private Button sortDate;
    private Button sortGenre;
    private Button next;
    private Button repHobby;
    private Button repMajor;
    private Button repRegion;
    private Button quit;
    private Iterator<GUIGlyph> iter;
    private int iteratorIndex;


    /**
     * Constructor that initializes all the instance data
     * 
     * @param GUIGlyphList
     *            is the list of GUIGlyphs that will be displayed
     */
    public GUIProjectWindow(LinkedList<GUIGlyph> GUIGlyphList)
    {
        this.gList = GUIGlyphList;
        iter = gList.iterator();
        // method that Sort by Genre button would call
        sortGlyphGenre();
        // method that sort by hobby button would call
        sortHobby();
        // method that sort by title button would call
        sortGlyphTitle();
        sortHobby();

        // instantiates a window
        window = new Window("Project 5");
        window.setSize(850, 450);

        // initializes buttons and glyphs
        initializeButtons();
        initializeGUIGlyphs(MajorEnum.class);

        // Creates a sample legend for current submission
        Shape outline = new Shape(705, 160, 115, 155, Color.BLACK);
        outline.setBackgroundColor(Color.WHITE);
        window.addShape(outline);

        TextShape legendTitle = new TextShape(710, 165, "Default Legend",
            Color.BLACK);
        window.addShape(legendTitle);
        window.moveToFront(legendTitle);
        legendTitle.setBackgroundColor(Color.WHITE);

        TextShape firstAttribute = new TextShape(710, 185, "Atrb1",
            Color.MAGENTA);
        TextShape secondAttribute = new TextShape(710, 200, "Atrb2",
            Color.BLUE);
        TextShape thirdAttribute = new TextShape(710, 215, "Atrb3",
            Color.ORANGE);
        TextShape fourthAttribute = new TextShape(710, 230, "Atrb4",
            Color.GREEN);

        firstAttribute.setBackgroundColor(Color.WHITE);
        secondAttribute.setBackgroundColor(Color.WHITE);
        thirdAttribute.setBackgroundColor(Color.WHITE);
        fourthAttribute.setBackgroundColor(Color.WHITE);

        window.addShape(firstAttribute);
        window.addShape(secondAttribute);
        window.addShape(thirdAttribute);
        window.addShape(fourthAttribute);
        window.moveToFront(firstAttribute);
        window.moveToFront(secondAttribute);
        window.moveToFront(thirdAttribute);
        window.moveToFront(fourthAttribute);

        TextShape legendSongTitle = new TextShape(725, 245, "Song Title",
            Color.BLACK);
        legendSongTitle.setBackgroundColor(Color.WHITE);
        window.addShape(legendSongTitle);
        window.moveToFront(legendSongTitle);

        TextShape legendHeard = new TextShape(720, 275, "Heard", Color.BLACK);
        legendHeard.setBackgroundColor(Color.WHITE);
        window.addShape(legendHeard);
        window.moveToFront(legendHeard);

        TextShape legendLiked = new TextShape(770, 275, "Likes", Color.BLACK);
        legendLiked.setBackgroundColor(Color.WHITE);
        window.addShape(legendLiked);
        window.moveToFront(legendLiked);

        Shape blackBar = new Shape(765, 265, 5, 40, Color.BLACK);
        window.addShape(blackBar);
        window.moveToFront(blackBar);

    }


    /**
     * Helper method that initializes the GUIGlyphs and displays them
     */
    private void initializeGUIGlyphs(Class<?> Class)
    {
        // this is not fully complete, as of now it only creates one glyph
        int offsetX = 200;
        int offsetY = 100;
        int refX = 120;
        int refY = 50;
        iteratorIndex = 0;
        for (int j = 1; j <= 9; j++)
        {
            if (iter.hasNext())
            {
                GUIGlyph glyph = iter.next();
                iteratorIndex++;
                Shape[] shapes;

                if (Class.equals(MajorEnum.class))
                {
                    shapes = glyph.getMajorShapes();
                }
                else if (Class.equals(RegionEnum.class))
                {
                    shapes = glyph.getRegionShapes();
                }
                else
                {
                    shapes = glyph.getHobbyShapes();
                }

                Shape blackBar = shapes[8];
                blackBar.setX(refX);
                blackBar.setY(refY);
                window.addShape(blackBar);

                int height = 0;
                // positions left bars
                for (int i = 0; i < 4; i++)
                {
                    shapes[i].setX(refX - shapes[i].getWidth());
                    shapes[i].setY(refY + height);
                    window.addShape(shapes[i]);
                    height += 10;
                }
                height = 0;
                // positions right bars
                for (int i = 4; i < 8; i++)
                {
                    shapes[i].setX(refX + blackBar.getWidth());
                    shapes[i].setY(refY + height);
                    window.addShape(shapes[i]);
                    height += 10;
                }

                // sets coordinates

                shapes[9].setX(refX - shapes[9].getWidth()/2);
                shapes[9].setY(refY - 40);
                shapes[9].setBackgroundColor(Color.WHITE);
                window.addShape(shapes[9]);

                shapes[10].setX(refX - shapes[10].getWidth()/2);
                shapes[10].setY(refY - 20);
                shapes[10].setBackgroundColor(Color.WHITE);
                window.addShape(shapes[10]);
            }

            if (j % 3 == 0)
            {
                refX = 120;
                refY += offsetY;
            }
            else
            {
                refX += offsetX;
            }
            
        }

    }


    /**
     * Initializes the buttons and displays them
     */
    private void initializeButtons()
    {
        // creates all buttons
        prev = new Button("<-- Prev");
        sortArtist = new Button("Sort by Artist Name");
        sortTitle = new Button("Sort by Song Title");
        sortDate = new Button("Sort by Release Year");
        sortGenre = new Button("Sort by Genre");
        next = new Button("Next -->");
        repHobby = new Button("Represent Hobby");
        repMajor = new Button("Represent Major");
        repRegion = new Button("Represent Region");
        quit = new Button("Quit");

        // adds all buttons
        window.addButton(prev, WindowSide.NORTH);
        window.addButton(sortArtist, WindowSide.NORTH);
        window.addButton(sortTitle, WindowSide.NORTH);
        window.addButton(sortDate, WindowSide.NORTH);
        window.addButton(sortGenre, WindowSide.NORTH);
        window.addButton(next, WindowSide.NORTH);
        window.addButton(repHobby, WindowSide.SOUTH);
        window.addButton(repMajor, WindowSide.SOUTH);
        window.addButton(repRegion, WindowSide.SOUTH);
        window.addButton(quit, WindowSide.SOUTH);
    }


    /**
     * Displays each GUIGlyph's information to the console per Hobby
     * 
     * @param gList
     *            is the list of GUIGlyphs used to display the information
     */
    private void sortHobby()
    {
        Object[] output = gList.toArray();
        // outputs info of songs sorted by hobby
        for (int i = 0; i < output.length; i++)
        {
            System.out.println("Song Title: " + ((GUIGlyph)output[i]).getSong()
                .getTitle());
            System.out.println("Song Artist: " + ((GUIGlyph)output[i]).getSong()
                .getArtist());
            System.out.println("Song Genre: " + ((GUIGlyph)output[i]).getSong()
                .getGenre());
            System.out.println("Song Year: " + ((GUIGlyph)output[i]).getSong()
                .getDate());

            // the 2D array is filled with info about each hobby for heard and
            // liked
            int[][] responses = ((GUIGlyph)output[i]).getSong().sortByHobby();
            for (int x = 0; x < responses.length; x++)
            {
                for (int y = 0; y < responses[0].length; y += 4)
                {
                    if (x == 0)
                    {
                        System.out.println("Heard");
                    }
                    else
                    {
                        System.out.println("Likes");
                    }
                    System.out.print("reading:" + responses[x][y] + " ");
                    System.out.print("art:" + responses[x][y + 1] + " ");
                    System.out.print("sports:" + responses[x][y + 2] + " ");
                    System.out.print("music:" + responses[x][y + 3]);
                    System.out.println();
                }
            }
            System.out.println();
        }
    }


    /**
     * Prints the GUIGlyph's information to the console per Major
     * 
     * @param gList
     *            is the list of GUIGlyphs used to display the information
     */
    private void sortMajor()
    {

        Object[] output = gList.toArray();
        for (int i = 0; i < output.length; i++)
        {
            System.out.println("Song Title: " + ((GUIGlyph)output[i]).getSong()
                .getTitle());
            System.out.println("Song Artist: " + ((GUIGlyph)output[i]).getSong()
                .getArtist());
            System.out.println("Song Genre: " + ((GUIGlyph)output[i]).getSong()
                .getGenre());
            System.out.println("Song Year: " + ((GUIGlyph)output[i]).getSong()
                .getDate());

            // the 2D array is filled with info about each major for heard and
            // liked
            int[][] responses = ((GUIGlyph)output[i]).getSong().sortByMajor();
            for (int x = 0; x < responses.length; x++)
            {
                for (int y = 0; y < responses[0].length; y += 4)
                {
                    if (x == 0)
                    {
                        System.out.println("Heard");
                    }
                    else
                    {
                        System.out.println("Likes");
                    }
                    System.out.print("Math or CMDA:" + responses[x][y] + " ");
                    System.out.print("Computer Science:" + responses[x][y + 1]
                        + " ");
                    System.out.print("Other Engineering:" + responses[x][y + 2]
                        + " ");
                    System.out.print("Other:" + responses[x][y + 3]);
                    System.out.println();
                }
            }
        }
        System.out.println();
    }


    /**
     * Prints the GUIGlyph's information to the console per Region
     * 
     * @param gList
     *            is the list of GUIGlyphs used to display the information
     */
    private void sortRegion()
    {
        Object[] output = gList.toArray();
        for (int i = 0; i < output.length; i++)
        {
            System.out.println("Song Title: " + ((GUIGlyph)output[i]).getSong()
                .getTitle());
            System.out.println("Song Artist: " + ((GUIGlyph)output[i]).getSong()
                .getArtist());
            System.out.println("Song Genre: " + ((GUIGlyph)output[i]).getSong()
                .getGenre());
            System.out.println("Song Year: " + ((GUIGlyph)output[i]).getSong()
                .getDate());

            // the 2D array is filled with info about each region for heard and
            // liked
            int[][] responses = ((GUIGlyph)output[i]).getSong().sortByRegion();
            for (int x = 0; x < responses.length; x++)
            {
                for (int y = 0; y < responses[0].length; y += 4)
                {
                    if (x == 0)
                    {
                        System.out.println("Heard");
                    }
                    else
                    {
                        System.out.println("Likes");
                    }
                    System.out.print("Northeast:" + responses[x][y] + " ");
                    System.out.print("Southeast:" + responses[x][y + 1] + " ");
                    System.out.print("United States:" + responses[x][y + 2]
                        + " ");
                    System.out.print("Other:" + responses[x][y + 3]);
                    System.out.println();
                    System.out.println();
                }
            }
        }
        System.out.println();
    }


    /**
     * Sorts the GUIGlyphs by genre
     * 
     * @param GUIGlyphList
     *            is the list of GUIGlyphs to be sorted
     */
    private void sortGlyphGenre()
    {
        Object[] arr = gList.toArray();
        int i, j, first;
        GUIGlyph temp;
        for (i = arr.length - 1; i > 0; i--)
        {
            first = 0; // initialize to subscript of first element
            for (j = 1; j <= i; j++) // locate smallest element between
                                     // positions 1 and i.
            {
                if (((GUIGlyph)arr[j]).getSong().getGenre().compareTo(
                    ((GUIGlyph)arr[first]).getSong().getGenre()) < 0)
                    first = j;
            }
            temp = ((GUIGlyph)arr[first]); // swap smallest found with element
                                           // in
                                           // position
            // i.
            arr[first] = arr[i];
            arr[i] = temp;
        }
        gList.clear();
        for (int z = arr.length - 1; z >= 0; z--)
        {
            gList.add(((GUIGlyph)arr[z]));
        }

    }


    /**
     * Sorts the GUIGlyphs by title
     * 
     * @param GUIGlyphList
     *            is the list of GUIGlyphs to be sorted
     */
    private void sortGlyphTitle()
    {
        Object[] arr = gList.toArray();
        int i, j, first;
        GUIGlyph temp;
        for (i = arr.length - 1; i > 0; i--)
        {
            first = 0; // initialize to subscript of first element
            for (j = 1; j <= i; j++) // locate smallest element between
                                     // positions 1 and i.
            {
                if (((GUIGlyph)arr[j]).getSong().getTitle().compareToIgnoreCase(
                    ((GUIGlyph)arr[first]).getSong().getTitle()) < 0)
                    first = j;
            }
            temp = ((GUIGlyph)arr[first]); // swap smallest found with element
                                           // in
                                           // position
            // i.
            arr[first] = arr[i];
            arr[i] = temp;
        }
        gList.clear();
        for (int z = arr.length - 1; z >= 0; z--)
        {
            gList.add(((GUIGlyph)arr[z]));
        }

    }
}
